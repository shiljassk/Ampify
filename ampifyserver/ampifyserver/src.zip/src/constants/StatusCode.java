package constants;

public enum StatusCode {
    ONLINE,
    BUSY,
    OFFLINE;
    
    StatusCode(){
        this.toString();
    }
}
