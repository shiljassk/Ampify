package constants;

public enum ResponseCode {
    SUCCESSFUL,
    FAILURE;
    
    ResponseCode(){
        this.toString();
    }
}
