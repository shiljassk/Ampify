package constants;

public enum FeedbackCode {
    LIKE,
    NONE,
    DISLIKE;
    
    FeedbackCode(){
        this.toString();
    }
}
