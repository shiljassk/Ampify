package constants;

public enum FeedbackCode {
    LIKE,
    DISLIKE;
    
    FeedbackCode(){
        this.toString();
    }
}
