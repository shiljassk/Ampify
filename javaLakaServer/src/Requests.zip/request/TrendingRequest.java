package request;

import constants.RequestCode;
import java.io.Serializable;

public class TrendingRequest extends Request implements Serializable{
     @Override
    public RequestCode getRequestCode(){
        return RequestCode.TRENDING;
    }
}
